import java.util.concurrent.ThreadLocalRandom;

public class Cofrinho {

    Double saldo;
    String propositoDinheiro;
    Boolean quebradoOuNao;

    void depositarDinheiro(Double valorRecebido) {
        if (!quebradoOuNao && valorRecebido > 0.0) {
            saldo += valorRecebido;
            System.out.println("Depósito realizado");
        } else {
            System.out.println("Erro no depósito");
        }
    }

    Double agitarCofre() {
        if (!quebradoOuNao) {
           Double valorAleatorio = ThreadLocalRandom.current().nextDouble(0.0, saldo);
           saldo -= valorAleatorio;
            return valorAleatorio;
        }
        return null;
    }

    Double quebrarCofre() {
        if (!quebradoOuNao) {
            Double valorAnterior = saldo;
            saldo = 0.0;
            quebradoOuNao = true; // quebrei e devolvi o dinheiro para o dono, não tirei
            return saldo;
        }
        return null;
    }

}
