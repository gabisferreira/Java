public class main {
    public static void main(String[] args) {

        Cofrinho cofrinho01 = new Cofrinho();

        cofrinho01.propositoDinheiro = "Comprar um carro bonito";
        cofrinho01.saldo = 0.0;
        cofrinho01.quebradoOuNao = true;

        cofrinho01.depositarDinheiro(50.10);
        Double valorResgatado = cofrinho01.quebrarCofre();

        if (valorResgatado == null) {
            System.out.println("Já foi quebrado");
        } else {
            System.out.println("Você quebrou e resgatou " + valorResgatado);
        }
    }
}
