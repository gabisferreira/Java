public class PrimeiraClasse {
    public static void main(String[] args) {

        String nome = "Bob";
        Integer idade = 42;
        Double altura = 1.55;

        System.out.println("Olá mundo java: " + nome);
    }
}
