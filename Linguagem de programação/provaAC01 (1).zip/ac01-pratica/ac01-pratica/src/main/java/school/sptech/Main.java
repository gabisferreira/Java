package school.sptech;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Cinema ProvaCinema = new Cinema();

        Integer sala = 4;

        Boolean numeroSala = ProvaCinema.validarSala(sala);
        System.out.println("Número da sala é valido: " + numeroSala);

//        Boolean sala3d = sala.equals(2);
//        sala3d = sala.equals(4);
//        Boolean imax = sala.equals(3);
//        imax = sala.equals(4);
        Boolean sala3d = false;
        Boolean imax = false;

        Double precoSala = ProvaCinema.calcularPrecoSala(sala3d, imax);
        System.out.println("Valor do cinema: " + precoSala);

        Boolean meiaEntrada = false;
        Double resultadoEntrada = ProvaCinema.calcularValorIngresso(sala, meiaEntrada);
//        System.out.println("Meia entrada ou não" + resultadoEntrada);

        Integer resultadoAcentos = ProvaCinema.contarQtdAcentosImpares(sala);
        System.out.println("Impar ou par:" + resultadoAcentos);
    }
}