package school.sptech;

import java.util.Scanner;

public class Cinema {

    Boolean validarSala(Integer sala) {

        if (sala.equals(null) || sala <= 0) {
            return false;
        }
        if (sala <=4){
            return true;
        }
        return false;
    }

    Double calcularPrecoSala(Boolean sala3d, Boolean imax) {
        Integer sala = 2;

        Double precoComum = 30.0;
        Double preco3d = 5.0;
        Double precoImax = 10.0;
        Double precoFinal = 0.0;

            if (sala.equals(1)) {
                sala3d = false;
                imax = false;
                precoFinal = precoComum;
            } else if (sala.equals(2)) {
                sala3d = sala.equals(2);
                sala3d = true;
                precoFinal = precoComum + preco3d;
            } else if (sala.equals(3)) {
                imax = sala.equals(3);
                precoFinal = precoComum + precoImax;
            } else if (sala.equals(4)) {
                sala3d = sala.equals(4);
                imax = sala.equals(4);
                precoFinal = precoComum + preco3d + precoImax;
            }
        return precoFinal;
    }

    Double calcularValorIngresso(Integer sala, Boolean meiaEntrada) {

        Double precoComum = 30.0;
        Double preco3d = 5.0;
        Double precoImax = 10.0;
        Double precoFinal = 0.0;

        String resultadoMeiaEntrada = meiaEntrada.equals(true) ? "Sim" : "Não";
        System.out.println("É meia entrada: " + resultadoMeiaEntrada);

        if (meiaEntrada.equals(true) && sala.equals(1)) {
            precoFinal = precoComum / 2;
        } else if (meiaEntrada.equals(false) && sala.equals(1)) {
            precoFinal = precoComum;
        }
        if (meiaEntrada.equals(true) && sala.equals(2)) {
            precoFinal = (precoComum + preco3d) / 2;
        } else if (meiaEntrada.equals(false) && sala.equals(2)) {
            precoFinal = precoComum + preco3d;
        }
        if (meiaEntrada.equals(true) && sala.equals(3)) {
            precoFinal = (precoComum + precoImax) / 2;
        } else if (meiaEntrada.equals(false) && sala.equals(3)) {
            precoFinal = precoComum + precoImax;
        }
        if (meiaEntrada.equals(true) && sala.equals(4)) {
            precoFinal = (precoComum + precoImax + preco3d) / 2;
        } else if (meiaEntrada.equals(false) && sala.equals(4)) {
            precoFinal = precoComum + precoImax + preco3d;
        }
        return precoFinal;
    }

    Integer contarQtdAcentosImpares(Integer sala) {
            Integer impares = 0;
            Integer resto = 0;
        if (sala.equals(1)) {
            for (int i = 0; i <= 50; i++) {
                resto = i % 2;

                if (resto.equals(1)) {
            impares++;}
            }
        }
        if (sala.equals(3)) {
            for (int i = 0; i <= 37; i++) {
                resto = i % 2;

                if (resto.equals(1)) {
                    impares++;}
            }
            }
        if (sala.equals(4)) {
            for (int i = 0; i <= 90; i++) {
                resto = i % 2;

                if (resto.equals(1)) {
                    impares++;}
            }
        }
        if (sala.equals(5)) {
            for (int i = 0; i <= 80; i++) {
                resto = i % 2;

                if (resto.equals(1)) {
                    impares++;}

            }
        }
        return impares;
    }

}