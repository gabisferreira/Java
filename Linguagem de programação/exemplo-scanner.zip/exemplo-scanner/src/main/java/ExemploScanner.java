import java.util.Scanner;

/*
 Pergunte o nome, idade, e altura
 e exiba usando interpolação
*/

public class ExemploScanner {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        Scanner leitorNl = new Scanner(System.in);

        System.out.println("Digite seu nome:");
        String nomeUsuario = leitorNl.nextLine();

        System.out.println("Digite sua idade:");
        Integer idadeUsuario = leitor.nextInt();

        System.out.println("Digite seu Pet:");
        String nomePet = leitor.nextLine();

        System.out.println("Digite sua altura:");
        Double alturaUsuario = leitor.nextDouble();

        System.out.println("""
                Nome: %s
                Idade: %d
                Altura: %.2f"""
                .formatted(nomeUsuario, idadeUsuario, alturaUsuario));
    }
}
