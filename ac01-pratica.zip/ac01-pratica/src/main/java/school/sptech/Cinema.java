package school.sptech;

public class Cinema {

}